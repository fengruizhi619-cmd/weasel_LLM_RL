# -*- coding: utf-8 -*-
"""cli_emojiless_exp_v0.2 - route A unified full-chain watcher.

WeaselExpContextV0 log -> reward check on previous tree
-> unified PyTorch RL update (lm_head) -> rebuild candidate tree
-> multi-slot checkpoint persistence.
"""
import argparse
import os
import re
import signal
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import unified_pipeline as up

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


class _TeeStream:
    def __init__(self, primary, sink):
        self.primary = primary
        self.sink = sink

    def write(self, text):
        self.primary.write(text)
        self.sink.write(text)

    def flush(self):
        self.primary.flush()
        self.sink.flush()


def _enable_watch_log(log_file):
    try:
        path = os.path.join(os.path.dirname(log_file), "unified-watcher.log")
        sink = open(path, "a", encoding="utf-8", errors="replace")
        sys.stdout = _TeeStream(sys.stdout, sink)
        sys.stderr = _TeeStream(sys.stderr, sink)
    except OSError:
        pass

CTX_RE = re.compile(r"ctx\(\d+/\d+\):\s(.+?)\s*$")


GHOST_DIR = os.path.join(os.environ.get("APPDATA", ""), "Rime")
GHOST_FILE = os.path.join(GHOST_DIR, "llm_inline_ghost.txt")

FNV_OFFSET = 14695981039346656037
FNV_PRIME = 1099511628211
FNV_MASK = (1 << 64) - 1

GHOST_MARKER_RE = re.compile(r"(?:<[^<>\n]{1,200}>)+$")


def clean_ghost_markers(context):
    open_sentinel = "\u2063"
    close_sentinel = "\u2064"
    while True:
        start = context.find(open_sentinel)
        if start < 0:
            break
        end = context.find(close_sentinel, start + 1)
        if end < 0:
            break
        context = context[:start] + context[end + 1:]
    return GHOST_MARKER_RE.sub("", context)


def ghost_hash(context):
    value = FNV_OFFSET
    for byte in context.encode("utf-8"):
        value = ((value ^ byte) * FNV_PRIME) & FNV_MASK
    return value


def clear_ghost_file():
    try:
        if os.path.exists(GHOST_FILE):
            os.remove(GHOST_FILE)
    except OSError:
        pass


def write_ghost_file(context, suggestion):
    try:
        os.makedirs(GHOST_DIR, exist_ok=True)
        text = suggestion or ""
        text = text.replace("\n", " ").replace("\r", " ")
        with open(GHOST_FILE, "w", encoding="utf-8") as f:
            f.write(format(ghost_hash(context), "x") + "\n" + text + "\n")
    except OSError:
        pass

SLOTS = [
    ("lm_head_t0.pt", 10),
    ("lm_head_t5m.pt", 300),
    ("lm_head_t25m.pt", 1500),
    ("lm_head_t2h.pt", 7200),
    ("lm_head_t12h.pt", 43200),
]


def find_best_reward(root, typed_text):
    if root is None or not typed_text:
        return 0.0, ""
    best = 0.0
    best_path = ""
    stack = [root]
    while stack:
        node = stack.pop()
        for child in node.children:
            path = child.path
            if not path:
                continue
            if typed_text.startswith(path):
                ratio = 1.0
                if len(typed_text) < len(path):
                    ratio = len(typed_text) / len(path)
                score = child.cum * ratio
                if score > best:
                    best = score
                    best_path = path
            stack.append(child)
    return best, best_path


class CheckpointManager:
    def __init__(self, engine, ckpt_dir):
        self.engine = engine
        self.ckpt_dir = ckpt_dir
        self.dirty = False
        self.updates = 0
        self.last_save = {}
        os.makedirs(ckpt_dir, exist_ok=True)

    def load_latest(self):
        import torch
        names = [name for name, _ in SLOTS]
        for name in names:
            path = os.path.join(self.ckpt_dir, name)
            if self.engine.load_checkpoint(path):
                try:
                    ckpt = torch.load(path, map_location=self.engine.device)
                    self.updates = int(ckpt.get("updates", 0))
                except Exception:
                    self.updates = 0
                return True
        return False

    def mark_dirty(self):
        self.dirty = True
        self.updates += 1

    def save_epoch(self, force=False):
        if not self.dirty:
            return
        now = time.time()
        for name, interval in SLOTS:
            last = self.last_save.get(name, 0.0)
            if force or (now - last) >= interval:
                self.engine.save_checkpoint(
                    os.path.join(self.ckpt_dir, name), updates=self.updates)
                self.last_save[name] = now
        self.dirty = False


def main():
    ap = argparse.ArgumentParser(
        description="cli_emojiless_exp_v0.2 unified full-chain watcher")
    ap.add_argument("--log-file", required=True)
    ap.add_argument("--model", default=up.MODEL_PATH)
    ap.add_argument("--device", default=up.DEVICE)
    ap.add_argument("--dtype", choices=["float32", "bfloat16", "float16"],
                    default="bfloat16" if up.DEVICE == "cuda" else "float32")
    ap.add_argument("--fp8", action="store_true")
    ap.add_argument("--skip-ckpt", action="store_true",
                    help="start from the base lm_head, do not load slots")
    ap.add_argument("--rl-lr", type=float, default=up.LR)
    ap.add_argument("-n", type=int, default=up.WIDTH)
    ap.add_argument("-d", type=int, default=up.DEPTH)
    ap.add_argument("--top-n", type=int, default=up.TOP_N)
    ap.add_argument("--ctx-chars", type=int, default=up.CTX_CHARS)
    ap.add_argument("--ckpt-dir", default="")
    args = ap.parse_args()

    log_file = os.path.abspath(args.log_file)
    ckpt_dir = args.ckpt_dir or os.path.join(
        os.path.dirname(log_file), "checkpoints")

    _enable_watch_log(log_file)
    print("[v0.2] unified full-chain watcher: "
          "context -> reward -> tree -> RL -> checkpoint", flush=True)
    print(f"[v0.2] log={log_file} model={args.model} "
          f"width={args.n} depth={args.d} lr={args.rl_lr}", flush=True)

    engine = up.TreeEngine(args.model, lr=args.rl_lr, device=args.device,
                           dtype=args.dtype, fp8=args.fp8)
    ckpt = CheckpointManager(engine, ckpt_dir)
    if args.skip_ckpt:
        print("[v0.2] skip checkpoint load: base lm_head", flush=True)
    elif ckpt.load_latest():
        print(f"[v0.2] resumed updates={ckpt.updates}", flush=True)

    if not os.path.exists(log_file):
        open(log_file, "a", encoding="utf-8").close()
    last_pos = os.path.getsize(log_file)

    prev_context = None
    prev_tree = None
    commit_count = 0
    running = True

    def stop_handler(_sig, _frame):
        nonlocal running
        running = False
    signal.signal(signal.SIGINT, stop_handler)

    print("\n[v0.2] ready. Type Chinese with Weasel in another app.\n",
          flush=True)

    try:
        while running:
            time.sleep(0.1)
            if not os.path.exists(log_file):
                continue
            cur_size = os.path.getsize(log_file)
            if cur_size <= last_pos:
                continue
            with open(log_file, "r", encoding="utf-8", errors="replace") as f:
                f.seek(last_pos)
                new_content = f.read()
            last_pos = os.path.getsize(log_file)

            for line in new_content.splitlines():
                m = CTX_RE.search(line)
                if not m:
                    continue
                ctx_text = m.group(1).strip()
                ctx_text = clean_ghost_markers(ctx_text)
                if not ctx_text:
                    continue
                if len(ctx_text) > args.ctx_chars:
                    ctx_text = ctx_text[-args.ctx_chars:]
                if ctx_text == prev_context:
                    continue
                commit_count += 1
                clear_ghost_file()

                reward = 0.0
                reward_path = ""
                typed = ""
                if prev_context and prev_tree:
                    if ctx_text.startswith(prev_context):
                        typed = ctx_text[len(prev_context):]
                        reward, reward_path = find_best_reward(prev_tree, typed)
                    else:
                        print(f"[commit #{commit_count}] diverged, skip reward",
                              flush=True)

                rl_line = ""
                if reward > 0.0 and typed:
                    loss = engine.rl_update(prev_context, typed, reward)
                    ckpt.mark_dirty()
                    ckpt.save_epoch()
                    rl_line = (f" reward={reward:.4f} path={reward_path!r} "
                               f"loss={loss:.6f} updates={ckpt.updates}")

                root, leaves, stats = engine.build_tree(
                    ctx_text, args.n, args.d)

                print(f"\n{'=' * 60}", flush=True)
                print(f"[commit #{commit_count}]", flush=True)
                print(f"[context] {ctx_text!r}", flush=True)
                print(f"[tree] {stats['time']:.2f}s "
                      f"nodes={stats['nodes']} leaves={stats['leaves']} "
                      f"forward_calls={stats.get('forward_calls', 0)}",
                      flush=True)
                if leaves:
                    print(f"[candidates] top {min(10, len(leaves))} "
                          f"by cum P:", flush=True)
                    for i, leaf in enumerate(leaves[:10], 1):
                        print(f"  {i:2d}. P={leaf.cum:.6f} {leaf.path!r}",
                              flush=True)
                ghost_sentence = leaves[0].path if leaves else ""
                print(f"[ghost-display] {ghost_sentence!r}", flush=True)
                if rl_line:
                    print(f"[RL]{rl_line}", flush=True)

                write_ghost_file(ctx_text, ghost_sentence)
                prev_context = ctx_text
                prev_tree = root

                ckpt.save_epoch()

    except Exception as exc:
        print(f"[v0.2] [ERROR] {exc}", file=sys.stderr, flush=True)
    finally:
        ckpt.save_epoch(force=True)
        print(f"\n[v0.2] stopped. commits={commit_count} "
              f"rl_updates={ckpt.updates}", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())