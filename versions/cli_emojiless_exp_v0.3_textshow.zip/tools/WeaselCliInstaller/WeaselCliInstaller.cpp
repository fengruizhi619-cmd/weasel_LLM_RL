// [CLI-000 SECTION-INDEX]
#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <shellapi.h>
#include <sddl.h>

#include <string>
#include <vector>
#include <fstream>
#include <algorithm>

// [CLI-001 HELPERS]
static std::wstring ModuleRoot() {
  wchar_t path[MAX_PATH]{};
  GetModuleFileNameW(nullptr, path, MAX_PATH);
  std::wstring file(path);
  size_t slash = file.find_last_of(L'\\');
  return slash == std::wstring::npos ? L"." : file.substr(0, slash);
}

static bool IsAdmin() {
  BOOL is_admin = FALSE;
  SID_IDENTIFIER_AUTHORITY authority = SECURITY_NT_AUTHORITY;
  PSID group = nullptr;
  if (AllocateAndInitializeSid(&authority, 2, SECURITY_BUILTIN_DOMAIN_RID,
                               DOMAIN_ALIAS_RID_ADMINS, 0, 0, 0, 0, 0, 0,
                               &group)) {
    CheckTokenMembership(nullptr, group, &is_admin);
    FreeSid(group);
  }
  return is_admin != FALSE;
}

static int RelaunchElevated(const std::wstring& command_line) {
  std::wstring exe = ModuleRoot() + L"\\WeaselCliInstaller.exe";
  SHELLEXECUTEINFOW info{};
  info.cbSize = sizeof(info);
  info.lpVerb = L"runas";
  info.lpFile = exe.c_str();
  info.lpParameters = command_line.c_str();
  info.nShow = SW_HIDE;
  info.fMask = SEE_MASK_NOCLOSEPROCESS;
  if (!ShellExecuteExW(&info) || info.hProcess == nullptr)
    return 1;
  WaitForSingleObject(info.hProcess, INFINITE);
  DWORD exit_code = 1;
  GetExitCodeProcess(info.hProcess, &exit_code);
  CloseHandle(info.hProcess);
  return static_cast<int>(exit_code);
}

static void Print(const std::wstring& text) {
  HANDLE output = GetStdHandle(STD_OUTPUT_HANDLE);
  DWORD mode = 0;
  if (output != INVALID_HANDLE_VALUE && output != nullptr &&
      GetConsoleMode(output, &mode)) {
    std::wstring line = text + L"\n";
    DWORD written = 0;
    WriteConsoleW(output, line.c_str(), static_cast<DWORD>(line.size()),
                  &written, nullptr);
  } else {
    fwprintf(stdout, L"%s\n", text.c_str());
  }
}

// [CLI-002 PROCESS-RUNNER]
static int RunFile(const std::wstring& root, const std::wstring& file,
                   const std::wstring& arguments) {
  std::wstring executable = root + L"\\" + file;
  std::wstring command_line = L"\"" + executable + L"\" " + arguments;
  STARTUPINFOW startup{};
  startup.cb = sizeof(startup);
  startup.dwFlags = STARTF_USESHOWWINDOW;
  startup.wShowWindow = SW_HIDE;
  PROCESS_INFORMATION process{};
  if (!CreateProcessW(executable.c_str(), command_line.data(), nullptr,
                      nullptr, FALSE, CREATE_NO_WINDOW, nullptr,
                      root.c_str(), &startup, &process)) {
    Print(L"[ERROR] cannot start " + executable + L" error=" +
          std::to_wstring(GetLastError()));
    return 1;
  }
  WaitForSingleObject(process.hProcess, INFINITE);
  DWORD exit_code = 0;
  GetExitCodeProcess(process.hProcess, &exit_code);
  CloseHandle(process.hThread);
  CloseHandle(process.hProcess);
  Print(file + L" exit=" + std::to_wstring(exit_code));
  return static_cast<int>(exit_code);
}

static int StartServer(const std::wstring& root) {
  std::wstring executable = root + L"\\WeaselServer.exe";
  STARTUPINFOW startup{};
  startup.cb = sizeof(startup);
  startup.dwFlags = STARTF_USESHOWWINDOW;
  startup.wShowWindow = SW_HIDE;
  PROCESS_INFORMATION process{};
  if (!CreateProcessW(executable.c_str(), nullptr, nullptr, nullptr, FALSE,
                      CREATE_NO_WINDOW, nullptr, root.c_str(), &startup,
                      &process)) {
    Print(L"[ERROR] cannot start WeaselServer.exe error=" +
          std::to_wstring(GetLastError()));
    return 1;
  }
  CloseHandle(process.hThread);
  CloseHandle(process.hProcess);
  Print(L"WeaselServer.exe started");
  return 0;
}

static int SetRegistry(const std::wstring& root) {
  HKEY key = nullptr;
  LONG result = RegOpenKeyExW(HKEY_LOCAL_MACHINE, L"Software\\Rime\\Weasel", 0,
                              KEY_SET_VALUE, &key);
  if (result == ERROR_SUCCESS) {
    RegSetValueExW(key, L"WeaselRoot", 0, REG_SZ,
                   reinterpret_cast<const BYTE*>(root.c_str()),
                   static_cast<DWORD>((root.size() + 1) * sizeof(wchar_t)));
    const std::wstring server = L"WeaselServer.exe";
    RegSetValueExW(key, L"ServerExecutable", 0, REG_SZ,
                   reinterpret_cast<const BYTE*>(server.c_str()),
                   static_cast<DWORD>((server.size() + 1) * sizeof(wchar_t)));
    RegCloseKey(key);
  }
  return result == ERROR_SUCCESS ? 0 : 1;
}

static int SetCurrentUserRimeRegistry() {
  wchar_t user_data[MAX_PATH]{};
  if (!ExpandEnvironmentStringsW(L"%APPDATA%\\Rime", user_data, MAX_PATH))
    return 1;

  HKEY key = nullptr;
  LONG result = RegCreateKeyExW(HKEY_CURRENT_USER, L"Software\\Rime\\Weasel",
                                0, nullptr, 0, KEY_SET_VALUE, nullptr, &key,
                                nullptr);
  if (result != ERROR_SUCCESS)
    return 1;

  const std::wstring rime_user_dir = user_data;
  const std::wstring profile = L"hans";
  DWORD hant = 0;
  RegSetValueExW(key, L"RimeUserDir", 0, REG_SZ,
                 reinterpret_cast<const BYTE*>(rime_user_dir.c_str()),
                 static_cast<DWORD>((rime_user_dir.size() + 1) *
                                    sizeof(wchar_t)));
  RegSetValueExW(key, L"Profile", 0, REG_SZ,
                 reinterpret_cast<const BYTE*>(profile.c_str()),
                 static_cast<DWORD>((profile.size() + 1) * sizeof(wchar_t)));
  RegSetValueExW(key, L"Hant", 0, REG_DWORD,
                 reinterpret_cast<const BYTE*>(&hant), sizeof(hant));
  RegCloseKey(key);
  return 0;
}

static void ClearCurrentUserRimeRegistry() {
  RegDeleteTreeW(HKEY_CURRENT_USER, L"Software\\Rime\\Weasel");
}

static void PrintUserDirStatus() {
  wchar_t value[MAX_PATH]{};
  DWORD value_size = sizeof(value);
  HKEY key = nullptr;
  LONG result =
      RegOpenKeyExW(HKEY_CURRENT_USER, L"Software\\Rime\\Weasel", 0,
                    KEY_QUERY_VALUE, &key);
  if (result == ERROR_SUCCESS) {
    result = RegQueryValueExW(key, L"RimeUserDir", nullptr, nullptr,
                              reinterpret_cast<LPBYTE>(value), &value_size);
    RegCloseKey(key);
  }
  if (result == ERROR_SUCCESS && value[0])
    Print(L"[status] user data dir=" + std::wstring(value));
  else
    Print(L"[status] user data dir=(not set)");
}

static void PrintUsage() {
  Print(L"WeaselCliInstaller [command]");
  Print(L"  install   - silent install from this package root");
  Print(L"  uninstall - silent uninstall of registered Weasel TSF");
  Print(L"  deploy    - deploy Rime user workspace");
  Print(L"  fix-userdir - force RimeUserDir to %APPDATA%\\Rime");
  Print(L"  schemas     - list available schemas (shared data dir)");
  Print(L"  set-schema <schema_id> - write default.custom.yaml with schema first, then deploy");
  Print(L"  status    - print current installation status");
}

// [CLI-003 ACTIONS]
static int DoInstall(const std::wstring& root) {
  Print(L"[install] root=" + root);
  if (RunFile(root, L"WeaselServer.exe", L"/q") != 0)
    Print(L"[warn] existing server quit returned nonzero");
  int setup = RunFile(root, L"WeaselSetup.exe", L"/s");
  if (setup != 0)
    return setup;
  if (SetCurrentUserRimeRegistry() != 0) {
    Print(L"[ERROR] cannot overwrite HKCU RimeUserDir");
    return 1;
  }
  Print(L"[install] RimeUserDir overwritten to %APPDATA%\\Rime");
  // /install shows the GUI first-run wizard; /deploy is the headless equivalent.
  int deployer = RunFile(root, L"WeaselDeployer.exe", L"/deploy");
  if (deployer != 0)
    return deployer;
  if (SetRegistry(root) != 0)
    Print(L"[warn] WeaselRoot registry update failed");
  return StartServer(root);
}

static int DoUninstall(const std::wstring& root) {
  Print(L"[uninstall] root=" + root);
  RunFile(root, L"WeaselServer.exe", L"/q");
  int setup = RunFile(root, L"WeaselSetup.exe", L"/u");
  ClearCurrentUserRimeRegistry();
  Print(L"[uninstall] HKCU Software\\Rime\\Weasel cleared");
  return setup;
}

static int DoDeploy(const std::wstring& root) {
  Print(L"[deploy] root=" + root);
  return RunFile(root, L"WeaselDeployer.exe", L"/deploy");
}

static int DoStatus(const std::wstring& root) {
  Print(L"[status] root=" + root);
  wchar_t value[MAX_PATH]{};
  DWORD value_size = sizeof(value);
  HKEY key = nullptr;
  LONG result =
      RegOpenKeyExW(HKEY_LOCAL_MACHINE, L"Software\\Rime\\Weasel", 0,
                    KEY_QUERY_VALUE, &key);
  if (result == ERROR_SUCCESS) {
    result = RegQueryValueExW(key, L"WeaselRoot", nullptr, nullptr,
                              reinterpret_cast<LPBYTE>(value), &value_size);
    RegCloseKey(key);
  }
  if (result == ERROR_SUCCESS && value[0])
    Print(L"[status] installed root=" + std::wstring(value));
  else
    Print(L"[status] installed root=(not set)");
  PrintUserDirStatus();
  return 0;
}

// [CLI-004 SCHEMA-CONFIG]
static std::wstring GetUserDataDir() {
  HKEY key = nullptr;
  wchar_t value[MAX_PATH]{};
  DWORD value_size = sizeof(value);
  LONG result = RegOpenKeyExW(HKEY_CURRENT_USER, L"Software\\Rime\\Weasel", 0,
                              KEY_QUERY_VALUE, &key);
  if (result == ERROR_SUCCESS) {
    result = RegQueryValueExW(key, L"RimeUserDir", nullptr, nullptr,
                              reinterpret_cast<LPBYTE>(value), &value_size);
    RegCloseKey(key);
  }
  if (result == ERROR_SUCCESS && value[0])
    return std::wstring(value);
  wchar_t fallback[MAX_PATH]{};
  if (ExpandEnvironmentStringsW(L"%APPDATA%\\Rime", fallback, MAX_PATH))
    return std::wstring(fallback);
  return L"";
}

static std::wstring GetSharedDataDir() {
  HKEY key = nullptr;
  wchar_t value[MAX_PATH]{};
  DWORD value_size = sizeof(value);
  LONG result = RegOpenKeyExW(HKEY_LOCAL_MACHINE, L"Software\\Rime\\Weasel", 0,
                              KEY_QUERY_VALUE, &key);
  if (result == ERROR_SUCCESS) {
    result = RegQueryValueExW(key, L"WeaselRoot", nullptr, nullptr,
                              reinterpret_cast<LPBYTE>(value), &value_size);
    RegCloseKey(key);
  }
  if (result == ERROR_SUCCESS && value[0])
    return std::wstring(value) + L"\\data";
  return ModuleRoot() + L"\\data";
}

static std::string WideToUtf8(const std::wstring& w) {
  if (w.empty())
    return std::string();
  int len = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), static_cast<int>(w.size()),
                                nullptr, 0, nullptr, nullptr);
  std::string s(static_cast<size_t>(len), '\0');
  WideCharToMultiByte(CP_UTF8, 0, w.c_str(), static_cast<int>(w.size()), &s[0],
                      len, nullptr, nullptr);
  return s;
}

static std::wstring Utf8ToWide(const std::string& u) {
  if (u.empty())
    return std::wstring();
  int len = MultiByteToWideChar(CP_UTF8, 0, u.c_str(), static_cast<int>(u.size()),
                                nullptr, 0);
  std::wstring w(static_cast<size_t>(len), L'\0');
  MultiByteToWideChar(CP_UTF8, 0, u.c_str(), static_cast<int>(u.size()), &w[0],
                      len);
  return w;
}

static std::wstring TrimWide(const std::wstring& text) {
  size_t begin = text.find_first_not_of(L" \t\r\n");
  if (begin == std::wstring::npos)
    return L"";
  size_t end = text.find_last_not_of(L" \t\r\n");
  return text.substr(begin, end - begin + 1);
}

static bool SchemaFileExists(const std::wstring& schema_id) {
  for (const std::wstring& dir : {GetSharedDataDir(), GetUserDataDir()}) {
    std::wstring path = dir + L"\\" + schema_id + L".schema.yaml";
    if (GetFileAttributesW(path.c_str()) != INVALID_FILE_ATTRIBUTES)
      return true;
  }
  return false;
}

static std::vector<std::wstring> BuiltinSchemaOrder(const std::wstring& shared_dir) {
  std::vector<std::wstring> order;
  std::ifstream in((shared_dir + L"\\default.yaml").c_str());
  std::string line;
  const std::string marker = "- schema:";
  while (std::getline(in, line)) {
    size_t pos = line.find(marker);
    if (pos == std::string::npos)
      continue;
    std::wstring id = Utf8ToWide(line.substr(pos + marker.size()));
    id = TrimWide(id);
    if (!id.empty())
      order.push_back(id);
  }
  return order;
}

static void DoListSchemas() {
  std::wstring shared = GetSharedDataDir();
  Print(L"[schemas] shared data dir=" + shared);
  std::vector<std::wstring> ids;
  WIN32_FIND_DATAW fd{};
  HANDLE hFind = FindFirstFileW((shared + L"\\*.schema.yaml").c_str(), &fd);
  if (hFind == INVALID_HANDLE_VALUE) {
    Print(L"[schemas] (none found)");
    return;
  }
  do {
    std::wstring name(fd.cFileName);
    size_t suffix = name.rfind(L".schema.yaml");
    if (suffix != std::wstring::npos)
      ids.push_back(name.substr(0, suffix));
  } while (FindNextFileW(hFind, &fd));
  FindClose(hFind);
  std::sort(ids.begin(), ids.end());
  for (const std::wstring& id : ids)
    Print(L"  - " + id);
}

static int DoSetSchema(const std::wstring& schema_id) {
  if (!SchemaFileExists(schema_id)) {
    Print(L"[set-schema] schema not found: " + schema_id);
    return 1;
  }
  std::wstring shared = GetSharedDataDir();
  std::wstring user = GetUserDataDir();
  if (user.empty()) {
    Print(L"[set-schema] cannot locate user data dir");
    return 1;
  }
  std::vector<std::wstring> order = BuiltinSchemaOrder(shared);
  order.erase(std::remove(order.begin(), order.end(), schema_id), order.end());
  order.insert(order.begin(), schema_id);
  std::ofstream out((user + L"\\default.custom.yaml").c_str(),
                    std::ios::trunc | std::ios::binary);
  out << "patch:\n  schema_list:\n";
  for (const std::wstring& id : order)
    out << "    - schema: " << WideToUtf8(id) << "\n";
  out.close();
  Print(L"[set-schema] default.custom.yaml updated, first schema=" + schema_id);
  int deployer = RunFile(ModuleRoot(), L"WeaselDeployer.exe", L"/deploy");
  if (deployer != 0) {
    Print(L"[set-schema] deploy failed exit=" + std::to_wstring(deployer));
    return deployer;
  }
  RunFile(ModuleRoot(), L"WeaselServer.exe", L"/q");
  return StartServer(ModuleRoot());
}

// [CLI-005 ENTRY]
int wmain() {
  int argc = 0;
  LPWSTR* argv = CommandLineToArgvW(GetCommandLineW(), &argc);
  std::wstring command = argc > 1 ? argv[1] : L"";
  std::wstring arg2 = argc > 2 ? argv[2] : L"";
  if (argv)
    LocalFree(argv);

  if (command.empty() || command == L"/?" || command == L"/help" ||
      command == L"-h" || command == L"help") {
    PrintUsage();
    return command.empty() ? 2 : 0;
  }

  std::wstring root = ModuleRoot();
  if (!IsAdmin() && command != L"status" && command != L"fix-userdir" &&
      command != L"schemas" && command != L"set-schema") {
    Print(L"[auth] requiring administrator privileges");
    return RelaunchElevated(command);
  }

  if (command == L"install")
    return DoInstall(root);
  if (command == L"uninstall")
    return DoUninstall(root);
  if (command == L"deploy")
    return DoDeploy(root);
  if (command == L"fix-userdir") {
    Print(L"[fix-userdir] overwriting HKCU RimeUserDir");
    if (SetCurrentUserRimeRegistry() != 0)
      return 1;
    Print(L"[fix-userdir] done");
    return 0;
  }
  if (command == L"status")
    return DoStatus(root);
  if (command == L"schemas") {
    DoListSchemas();
    return 0;
  }
  if (command == L"set-schema") {
    if (arg2.empty()) {
      Print(L"[set-schema] usage: set-schema <schema_id>");
      return 2;
    }
    return DoSetSchema(arg2);
  }

  Print(L"unknown command: " + command);
  return 2;
}
