# 在线统一引擎（S1-S6）

一个 PyTorch 模型同时干两件事：给输入法出候选、吃用户的采纳/回退做在线 SGD。
主干 fp16 冻结，lm_head fp32 可训；训练与推理共用同一份权重，梯度立刻影响下一棵树。

## 一键启动

```
start-online.cmd     启动 WeaselServer + 上下文钩子 + 引擎服务(8081)
stop-online.cmd      停引擎和钩子，WeaselServer 保持运行
```

## 接口

| 端点 | 说明 |
|---|---|
| POST /completion | llama-server 兼容：prompt/n_probs/temperature/top_k/top_p/min_p/repeat_penalty/repeat_last_n -> completion_probabilities[0].top_probs[{token,prob,id,pinyin}] |
| GET /health | 存活检查 |
| GET /metrics | 请求数/缓存命中/延迟分位/RL 次数/回退次数/回滚次数 |
| POST /feedback | 预留：{"kind":"accept"|"reject"} |

额外字段 `pinyin`（可选）：只返回拼音前缀匹配的候选（S3）。

## 参数

| 参数 | 默认 | 说明 |
|---|---|---|
| --dtype | float16 | 主干精度（头恒为 fp32） |
| -n/--width | 20 | 候选树宽度 |
| -d/--depth | 2 | 候选树深度 |
| --rl-lr | 1e-4 | 单样本 SGD 学习率 |
| --idle-gate | 0.3 | 距上次请求不足该秒数则不训练（S5） |
| --grad-clip | 1.0 | 梯度范数裁剪（S5） |
| --step-timeout | 2.0 | 单步超时则回滚该步（S5） |
| --eval-every | 50 | 每 N 次更新做一次回归探针（S5） |
| --rollback-margin | 0.05 | 探针低于基线该幅度则回滚到 t2h 槽（S5） |

## 数据

- checkpoint：diag/checkpoints_online/lm_head_t0|t5m|t25m|t2h|t12h.pt（只存头，5 槽时间稀释，启动 resume）
- 语料：diag/corpus.jsonl（XOR+base64 混淆落盘，键由 WEASEL_CORPUS_KEY/用户名派生）
- 日志：diag/online-server.log、diag/exp-run-v02.log

## 兼容性 / 降级

- 引擎没起来：输入法照常工作，只是没有 ghost 预览（TSF 侧 HTTP 失败即返回空）。
- 临时关掉联想：给目标进程设 WEASEL_GHOST_DISABLE=1。
- 换推理地址：设 WEASEL_GHOST_URL（默认 http://127.0.0.1:8081/completion）。
- 应用黑名单：目前靠上述环境变量 + 逐应用验证，矩阵见 design/v0.3/weasel-llm-v0.3-build-plan.md。
