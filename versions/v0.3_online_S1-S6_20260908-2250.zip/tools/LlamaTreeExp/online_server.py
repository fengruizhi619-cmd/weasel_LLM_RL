#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Online unified engine service (S1-S5).

One PyTorch model (frozen fp16 backbone + trainable fp32 lm_head) does two jobs:
  * serve a llama-server compatible /completion API for the IME front end (S1)
  * run the single-sample online RL loop over the context log (S2/S5)

Endpoints
  POST /completion   llama-server compatible top-k probabilities
  GET  /health       liveness
  GET  /metrics      counters (S4)
  POST /feedback     optional explicit accept/reject signal (S4 hook for TSF)

Extra request field
  "pinyin": "mingt"  constrain candidates to that pinyin prefix (S3)
"""
import argparse
import base64
import hashlib
import json
import os
import re
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import torch
import torch.nn.functional as F

import unified_pipeline as up
import unified_watcher as uw

CTX_RE = re.compile(r"ctx\(\d+/\d+\):\s(.+?)\s*$")

try:
    from pypinyin import lazy_pinyin
except Exception:  # pragma: no cover
    lazy_pinyin = None


def norm_pinyin(text):
    return re.sub(r"[^a-z]", "", text.lower())


def token_pinyin(tok):
    """Pinyin for a candidate token; latin/digits pass through as-is."""
    if lazy_pinyin is None:
        return norm_pinyin(tok)
    return norm_pinyin("".join(lazy_pinyin(tok)))


class Metrics:
    def __init__(self):
        self.lock = threading.Lock()
        self.start = time.time()
        self.requests = 0
        self.cache_hits = 0
        self.prompt_tokens = 0
        self.latency_ms = []
        self.empty_results = 0
        self.pinyin_filtered = 0
        self.rl_updates = 0
        self.rl_rewards = 0
        self.rl_backspaces = 0
        self.rollbacks = 0
        self.accepts = 0
        self.rejects = 0

    def bump(self, name, value=1):
        with self.lock:
            setattr(self, name, getattr(self, name) + value)

    def snapshot(self):
        with self.lock:
            lat = sorted(self.latency_ms)
            def pct(p):
                if not lat:
                    return 0.0
                return lat[min(len(lat) - 1, int(len(lat) * p))]
            return {
                "uptime_s": round(time.time() - self.start, 1),
                "requests": self.requests,
                "cache_hits": self.cache_hits,
                "prompt_tokens": self.prompt_tokens,
                "latency_p50_ms": round(pct(0.5), 1),
                "latency_p99_ms": round(pct(0.99), 1),
                "empty_results": self.empty_results,
                "pinyin_filtered": self.pinyin_filtered,
                "rl_updates": self.rl_updates,
                "rl_rewards": self.rl_rewards,
                "rl_backspaces": self.rl_backspaces,
                "rollbacks": self.rollbacks,
                "accepts": self.accepts,
                "rejects": self.rejects,
            }


class CorpusWriter:
    """Append-only encrypted corpus (S4). Key is derived per user/machine."""

    def __init__(self, path, key=None):
        self.path = path
        os.makedirs(os.path.dirname(path), exist_ok=True)
        seed = (key or os.environ.get("WEASEL_CORPUS_KEY") or
                os.environ.get("USERNAME", "local")).encode("utf-8")
        self.key = hashlib.sha256(seed).digest()

    def _xor(self, data):
        k = self.key
        return bytes(b ^ k[i % len(k)] for i, b in enumerate(data))

    def write(self, record):
        raw = json.dumps(record, ensure_ascii=False).encode("utf-8")
        blob = base64.b64encode(self._xor(raw)).decode("ascii")
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(blob + "\n")

    def read_all(self):
        out = []
        if not os.path.exists(self.path):
            return out
        with open(self.path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    out.append(json.loads(self._xor(base64.b64decode(line)).decode("utf-8")))
                except Exception:
                    continue
        return out


class EngineService:
    """Model owner: serves top-k probabilities and performs RL steps."""

    def __init__(self, engine, ckpt, corpus, metrics, args):
        self.engine = engine
        self.ckpt = ckpt
        self.corpus = corpus
        self.metrics = metrics
        self.args = args
        self.lock = threading.RLock()
        self.cache_tokens = []
        self.cache_kv = None
        self.cache_logits = None
        self.last_request = 0.0
        self.baseline = None
        self.probe = [
            ("天阴沉沉的，明天的天气", "怎么样"),
            ("今天吃饭了吗，我还没", "吃"),
            ("所以我们需要找到一个", "能力"),
        ]

    # ---------- S1: llama-server compatible completion ----------
    def complete(self, req):
        t0 = time.perf_counter()
        prompt = req.get("prompt", "")
        n_probs = int(req.get("n_probs", 20) or 20)
        repeat_penalty = float(req.get("repeat_penalty", 1.0) or 1.0)
        repeat_last_n = int(req.get("repeat_last_n", 64) or 64)
        temperature = float(req.get("temperature", 1.0) or 1.0)
        top_k = int(req.get("top_k", 0) or 0)
        top_p = float(req.get("top_p", 1.0) or 1.0)
        min_p = float(req.get("min_p", 0.0) or 0.0)
        pinyin = norm_pinyin(req.get("pinyin", "") or "")

        with self.lock:
            self.last_request = time.time()
            ids = self.engine.tokenizer.encode(prompt, add_special_tokens=False)
            logits, cached = self._forward_cached(ids)
            self.metrics.bump("requests")
            self.metrics.bump("prompt_tokens", len(ids))
            if cached:
                self.metrics.bump("cache_hits")

            scores = logits.float().clone()
            if repeat_penalty != 1.0 and repeat_last_n > 0:
                for token_id in set(ids[-repeat_last_n:]):
                    if scores[token_id] > 0:
                        scores[token_id] /= repeat_penalty
                    else:
                        scores[token_id] *= repeat_penalty
            if temperature > 0 and temperature != 1.0:
                scores = scores / temperature
            if top_k > 0:
                kth = torch.topk(scores, min(top_k, scores.numel())).values[-1]
                scores[scores < kth] = -float("inf")
            probs = F.softmax(scores, dim=-1)
            if min_p > 0:
                probs[probs < probs.max() * min_p] = 0.0
            if 0.0 < top_p < 1.0:
                sorted_probs, sorted_idx = torch.sort(probs, descending=True)
                cumulative = torch.cumsum(sorted_probs, dim=-1)
                cutoff = cumulative > top_p
                cutoff[..., 1:] = cutoff[..., :-1].clone()
                cutoff[..., 0] = False
                sorted_probs[cutoff] = 0.0
                probs = torch.zeros_like(probs).scatter(0, sorted_idx, sorted_probs)
            total = probs.sum()
            if total > 0:
                probs = probs / total

            count = min(n_probs, int((probs > 0).sum().item()) or n_probs)
            top_probs, top_ids = torch.topk(probs, max(1, count))

            entries = []
            for prob, token_id in zip(top_probs.tolist(), top_ids.tolist()):
                token = self.engine.tokenizer.decode([int(token_id)])
                if not token:
                    continue
                entries.append({"id": int(token_id), "token": token,
                                "prob": float(prob),
                                "pinyin": token_pinyin(token)})

            if pinyin:
                filtered = []
                for item in entries:
                    tp = token_pinyin(item["token"])
                    if tp.startswith(pinyin) or (
                            not tp and item["token"].lower().startswith(pinyin)):
                        filtered.append(item)
                if filtered:
                    if len(filtered) != len(entries):
                        self.metrics.bump("pinyin_filtered")
                    entries = filtered

            if not entries:
                self.metrics.bump("empty_results")

        elapsed = (time.perf_counter() - t0) * 1000.0
        with self.metrics.lock:
            self.metrics.latency_ms.append(elapsed)
            if len(self.metrics.latency_ms) > 2000:
                self.metrics.latency_ms = self.metrics.latency_ms[-2000:]

        head = entries[0] if entries else {"token": "", "prob": 0.0, "id": -1}
        return {
            "content": head["token"],
            "stop": False,
            "tokens_predicted": 1,
            "completion_probabilities": [{
                "id": head["id"],
                "token": head["token"],
                "prob": head["prob"],
                "top_probs": entries,
            }],
        }

    def _forward_cached(self, ids):
        """Forward only the new suffix; reuse KV + last logits for repeats."""
        if not ids:
            return torch.zeros(self.engine.model.lm_head.weight.shape[0],
                               device=self.engine.device), False
        common = 0
        if self.cache_kv is not None and self.cache_tokens:
            limit = min(len(ids), len(self.cache_tokens))
            while common < limit and ids[common] == self.cache_tokens[common]:
                common += 1
        if common == len(ids) and self.cache_logits is not None:
            return self.cache_logits, True

        if common == 0:
            self.cache_kv = None
        elif common < len(self.cache_tokens) and hasattr(self.cache_kv, "crop"):
            self.cache_kv.crop(common)

        new_ids = ids[common:]
        tokens = torch.tensor([new_ids], device=self.engine.device)
        with torch.no_grad():
            logits, kv = self.engine.backbone_logits(tokens, self.cache_kv)
        self.cache_tokens = list(ids)
        self.cache_kv = kv
        self.cache_logits = logits[0]
        return self.cache_logits, common > 0

    def reset_cache(self):
        with self.lock:
            self.cache_tokens = []
            self.cache_kv = None
            self.cache_logits = None

    # ---------- S5: guarded RL step ----------
    def rl_step(self, context, typed, reward, negative=False):
        with self.lock:
            before = self.engine.model.lm_head.weight.detach().clone()
            t0 = time.perf_counter()
            if negative:
                loss = self.engine.rl_update_unlikelihood(context, typed, reward)
            else:
                loss = self.engine.rl_update(context, typed, reward)
            torch.nn.utils.clip_grad_norm_(
                [self.engine.model.lm_head.weight], self.args.grad_clip)
            elapsed = time.perf_counter() - t0
            if elapsed > self.args.step_timeout:
                self.engine.model.lm_head.weight.data.copy_(before)
                self.reset_cache()
                return None, elapsed
            self.reset_cache()
            return loss, elapsed

    # ---------- S5: regression probe ----------
    def probe_quality(self):
        with self.lock:
            total = 0.0
            for context, target in self.probe:
                ids = self.engine.tokenizer.encode(context, add_special_tokens=False)
                logits, _ = self._forward_cached(ids)
                probs = F.softmax(logits.float(), dim=-1)
                tid = self.engine.tokenizer.encode(target, add_special_tokens=False)[0]
                total += float(torch.log(probs[tid] + 1e-12))
            self.reset_cache()
            return total / len(self.probe)

    def maybe_rollback(self, ckpt_path):
        quality = self.probe_quality()
        if self.baseline is None:
            self.baseline = quality
            return False
        if quality < self.baseline - self.args.rollback_margin:
            if self.engine.load_checkpoint(ckpt_path):
                self.baseline = self.probe_quality()
                self.metrics.bump("rollbacks")
                self.reset_cache()
                return True
        self.baseline = max(self.baseline, quality)
        return False


class RLLoop(threading.Thread):
    """S2: context log -> reward / backspace negative -> SGD -> checkpoints."""

    def __init__(self, service, args):
        super().__init__(daemon=True)
        self.service = service
        self.args = args
        self.running = True
        self.prev_context = None
        self.prev_tree = None
        self.commits = 0
        self.since_eval = 0

    def run(self):
        log_file = os.path.abspath(self.args.log_file)
        if not os.path.exists(log_file):
            open(log_file, "a", encoding="utf-8").close()
        pos = os.path.getsize(log_file)
        engine = self.service.engine
        while self.running:
            time.sleep(0.15)
            try:
                size = os.path.getsize(log_file)
            except OSError:
                continue
            if size <= pos:
                continue
            with open(log_file, "r", encoding="utf-8", errors="replace") as f:
                f.seek(pos)
                chunk = f.read()
            pos = os.path.getsize(log_file)
            for line in chunk.splitlines():
                m = CTX_RE.search(line)
                if not m:
                    continue
                ctx = m.group(1).strip()
                if not ctx:
                    continue
                if len(ctx) > self.args.ctx_chars:
                    ctx = ctx[-self.args.ctx_chars:]
                self._on_commit(ctx)

    def _on_commit(self, ctx):
        service = self.service
        self.commits += 1
        idle = (time.time() - service.last_request) >= self.args.idle_gate
        reward = 0.0
        path = ""
        backspace = False
        if self.prev_context is not None and self.prev_tree is not None:
            if ctx.startswith(self.prev_context):
                typed = ctx[len(self.prev_context):]
                reward, path = uw.find_best_reward(self.prev_tree, typed)
            elif self.prev_context.startswith(ctx):
                # S2: real backspace -- the previously predicted text was rejected.
                backspace = True
                rejected = self.prev_context[len(ctx):]
                service.metrics.bump("rl_backspaces")
                service.corpus.write({"kind": "backspace", "ctx": ctx,
                                      "rejected": rejected,
                                      "time": time.time()})
                if idle:
                    loss, elapsed = service.rl_step(ctx, rejected, 1.0,
                                                    negative=True)
                    if loss is not None:
                        service.ckpt.mark_dirty()
                        service.metrics.bump("rl_updates")
                        print(f"[S2] backspace rejected={rejected!r} "
                              f"loss={loss:.4f} {elapsed*1000:.0f}ms", flush=True)
        if reward > 0:
            service.metrics.bump("rl_rewards")
            service.corpus.write({"kind": "accept", "ctx": self.prev_context,
                                  "typed": path, "reward": reward,
                                  "time": time.time()})
            if idle:
                loss, elapsed = service.rl_step(self.prev_context, path, reward)
                if loss is not None:
                    service.ckpt.mark_dirty()
                    service.metrics.bump("rl_updates")
                    print(f"[S1/S2] reward={reward:.4f} path={path!r} "
                          f"loss={loss:.4f} updates={service.ckpt.updates}",
                          flush=True)
        # Always resync the tree with the newest context so the next commit can
        # be scored (this is also the positive half of the backspace pairing).
        root, leaves, stats = service.engine.build_tree(
            ctx, self.args.width, self.args.depth)
        self.prev_tree = root
        self.prev_context = ctx
        service.ckpt.save_epoch()
        self.since_eval += 1
        if self.since_eval >= self.args.eval_every:
            self.since_eval = 0
            stable = os.path.join(service.ckpt.ckpt_dir, "lm_head_t2h.pt")
            if service.maybe_rollback(stable):
                print("[S5] rollback to stable checkpoint", flush=True)

    def stop(self):
        self.running = False


class Handler(BaseHTTPRequestHandler):
    service = None
    metrics = None

    def log_message(self, fmt, *args):
        pass

    def _send(self, code, payload):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.startswith("/health"):
            self._send(200, {"status": "ok"})
        elif self.path.startswith("/metrics"):
            self._send(200, self.metrics.snapshot())
        else:
            self._send(404, {"error": "not found"})

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0) or 0)
        raw = self.rfile.read(length) if length else b"{}"
        try:
            req = json.loads(raw.decode("utf-8"))
        except Exception as exc:
            self._send(400, {"error": str(exc)})
            return
        if self.path.startswith("/completion"):
            try:
                self._send(200, self.service.complete(req))
            except Exception as exc:  # never take the IME down
                self._send(500, {"error": repr(exc)})
        elif self.path.startswith("/feedback"):
            kind = req.get("kind", "")
            if kind == "accept":
                self.metrics.bump("accepts")
            elif kind == "reject":
                self.metrics.bump("rejects")
            self._send(200, {"ok": True})
        else:
            self._send(404, {"error": "not found"})


def main():
    ap = argparse.ArgumentParser(description="online unified engine service")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8081)
    ap.add_argument("--model", default=up.MODEL_PATH)
    ap.add_argument("--dtype", default="float16",
                    choices=["float32", "bfloat16", "float16"])
    ap.add_argument("--fp8", action="store_true")
    ap.add_argument("--device", default=up.DEVICE)
    ap.add_argument("--log-file", default=os.path.join(HERE, "diag", "exp-run-v02.log"))
    ap.add_argument("--ckpt-dir", default=os.path.join(HERE, "diag", "checkpoints_online"))
    ap.add_argument("--corpus", default=os.path.join(HERE, "diag", "corpus.jsonl"))
    ap.add_argument("--rl-lr", type=float, default=up.LR)
    ap.add_argument("-n", "--width", type=int, default=20)
    ap.add_argument("-d", "--depth", type=int, default=2)
    ap.add_argument("--ctx-chars", type=int, default=100)
    ap.add_argument("--idle-gate", type=float, default=0.3)
    ap.add_argument("--grad-clip", type=float, default=1.0)
    ap.add_argument("--step-timeout", type=float, default=2.0)
    ap.add_argument("--eval-every", type=int, default=50)
    ap.add_argument("--rollback-margin", type=float, default=0.05)
    args = ap.parse_args()

    metrics = Metrics()
    engine = up.TreeEngine(args.model, lr=args.rl_lr, device=args.device,
                           dtype=args.dtype, fp8=args.fp8)
    ckpt = uw.CheckpointManager(engine, args.ckpt_dir)
    if ckpt.load_latest():
        print(f"[S1] resumed updates={ckpt.updates}", flush=True)
    corpus = CorpusWriter(args.corpus)
    service = EngineService(engine, ckpt, corpus, metrics, args)

    Handler.service = service
    Handler.metrics = metrics
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    loop = RLLoop(service, args)
    loop.start()
    print(f"[S1] online engine listening on http://{args.host}:{args.port} "
          f"(width={args.width} depth={args.depth} dtype={args.dtype})", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        loop.stop()
        ckpt.save_epoch(force=True)
        server.server_close()


if __name__ == "__main__":
    sys.exit(main())
