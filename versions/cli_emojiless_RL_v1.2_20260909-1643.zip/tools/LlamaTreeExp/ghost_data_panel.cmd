@echo off
start "LLM Data Panel" "E:\python\pythonw.exe" "E:\codex_data\�о�\weasel-baseline\tools\LlamaTreeExp\ghost_data_panel.py"
