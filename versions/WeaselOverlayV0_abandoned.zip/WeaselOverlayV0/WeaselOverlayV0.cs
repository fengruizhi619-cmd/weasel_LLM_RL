using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Automation;
using System.Windows.Automation.Text;
using System.Windows.Forms;

namespace WeaselOverlayV0 {
  internal static class Native {
    [StructLayout(LayoutKind.Sequential)]
    public struct POINT { public int X; public int Y; }
    [StructLayout(LayoutKind.Sequential)]
    public struct RECT { public int Left, Top, Right, Bottom; }
    [StructLayout(LayoutKind.Sequential)]
    public struct GUITHREADINFO {
      public int cbSize;
      public int flags;
      public IntPtr hwndActive;
      public IntPtr hwndFocus;
      public IntPtr hwndCapture;
      public IntPtr hwndMenuOwner;
      public IntPtr hwndMoveSize;
      public IntPtr hwndCaret;
      public RECT rcCaret;
    }
    [StructLayout(LayoutKind.Sequential)]
    public struct KEYBDINPUT {
      public ushort wVk;
      public ushort wScan;
      public uint dwFlags;
      public uint time;
      public IntPtr dwExtraInfo;
    }
    [StructLayout(LayoutKind.Sequential)]
    public struct INPUT {
      public uint type;
      public KEYBDINPUT ki;
    }

    public const uint INPUT_KEYBOARD = 1;
    public const uint KEYEVENTF_UNICODE = 0x0004;
    public const uint KEYEVENTF_KEYUP = 0x0002;
    public const int WH_KEYBOARD_LL = 13;
    public const int WM_KEYDOWN = 0x0100;
    public const int VK_TAB = 0x09;
    public const int GWL_EXSTYLE = -20;
    public const int WS_EX_TOPMOST = 0x00000008;
    public const int WS_EX_TOOLWINDOW = 0x00000080;
    public const int WS_EX_NOACTIVATE = 0x08000000;
    public const int SW_SHOWNOACTIVATE = 4;
    public const int SWP_NOSIZE = 0x0001;
    public const int SWP_NOMOVE = 0x0002;
    public const int SWP_NOACTIVATE = 0x0010;
    public const int SWP_SHOWWINDOW = 0x0040;
    public static readonly IntPtr HWND_TOPMOST = new IntPtr(-1);

    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);
    [DllImport("user32.dll")] public static extern bool GetGUIThreadInfo(uint idThread, ref GUITHREADINFO lpgui);
    [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr hWnd, ref POINT lpPoint);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
    [DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT lpPoint);
    [DllImport("user32.dll")] public static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);
    [DllImport("user32.dll")] public static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);
    [DllImport("user32.dll")] public static extern bool UnhookWindowsHookEx(IntPtr hhk);
    [DllImport("user32.dll")] public static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
    [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);
    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr hWnd, int nIndex);
    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)] public static extern IntPtr GetModuleHandle(string lpModuleName);
  }

  public delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);

  public sealed class OverlayForm : Form {
    // [OVL-CFG] paths & timing
    private readonly string _ghostDir;
    private readonly string _ghostPath;
    private readonly string _logPath;
    private string _text = "";
    private DateTime _lastShown = DateTime.MinValue;
    private DateTime _lastFileSeen = DateTime.MinValue;
    private DateTime _lastLog = DateTime.MinValue;
    private IntPtr _hook = IntPtr.Zero;
    private LowLevelKeyboardProc _hookProc;
    private FileSystemWatcher _watcher;
    private readonly Timer _timer;
    private IntPtr _shownFg = IntPtr.Zero;

    public OverlayForm() {
      _ghostDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Rime");
      _ghostPath = Path.Combine(_ghostDir, "llm_inline_ghost.txt");
      _logPath = Path.Combine(_ghostDir, "overlay-debug.log");

      Text = "Weasel Overlay V0";
      ShowInTaskbar = false;
      StartPosition = FormStartPosition.Manual;
      FormBorderStyle = FormBorderStyle.None;
      AutoSize = true;
      AutoSizeMode = AutoSizeMode.GrowAndShrink;
      // accent border colour around a cream label, so the ghost is visually distinct
      BackColor = Color.FromArgb(52, 120, 190);
      Padding = new Padding(2);

      _label.AutoSize = true;
      _label.Font = new Font("Microsoft YaHei UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
      _label.ForeColor = Color.FromArgb(35, 35, 35);
      _label.BackColor = Color.FromArgb(255, 250, 220);
      _label.Padding = new Padding(10, 5, 10, 5);
      Controls.Add(_label);

      _timer = new Timer { Interval = 200 };
      _timer.Tick += OnTick;
      _timer.Start();

      InstallHook();
      StartWatcher();
      Hide();
    }

    private readonly Label _label = new Label();

    protected override bool ShowWithoutActivation { get { return true; } }
    protected override CreateParams CreateParams {
      get {
        var cp = base.CreateParams;
        cp.ExStyle |= Native.WS_EX_TOPMOST | Native.WS_EX_TOOLWINDOW | Native.WS_EX_NOACTIVATE;
        return cp;
      }
    }

    // [OVL-HOOK] low-level keyboard hook for Tab commit
    private void InstallHook() {
      if (_hook != IntPtr.Zero) return;
      try {
        _hookProc = HookCallback;
        using (var cur = Process.GetCurrentProcess()) {
          _hook = Native.SetWindowsHookEx(Native.WH_KEYBOARD_LL, _hookProc, Native.GetModuleHandle(cur.MainModule.ModuleName), 0);
        }
        Log("hook=" + (_hook != IntPtr.Zero ? "armed" : "failed"));
      } catch (Exception ex) {
        Log("hook error: " + ex.Message);
      }
    }

    // [OVL-GHOST] watch candidate file
    private void StartWatcher() {
      try {
        Directory.CreateDirectory(_ghostDir);
        _watcher = new FileSystemWatcher(_ghostDir, "llm_inline_ghost.txt");
        _watcher.NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.FileName | NotifyFilters.Size;
        _watcher.Changed += OnGhostChanged;
        _watcher.Created += OnGhostChanged;
        _watcher.Deleted += OnGhostChanged;
        _watcher.EnableRaisingEvents = true;
      } catch (Exception ex) {
        Log("watcher error: " + ex.Message);
      }
    }

    private void OnGhostChanged(object sender, FileSystemEventArgs e) {
      try {
        if (e.ChangeType == WatcherChangeTypes.Deleted)
          BeginInvoke(new Action(HidePreview));
        else
          BeginInvoke(new Action(TryShowPreview));
      } catch { }
    }

    private void OnTick(object sender, EventArgs e) {
      // auto-hide when stale (no new candidate for 8s) or foreground app changed
      if (Visible) {
        if (DateTime.UtcNow - _lastShown > TimeSpan.FromSeconds(8)) {
          Log("autohide: stale");
          HidePreview();
          return;
        }
        var fg = Native.GetForegroundWindow();
        if (fg != _shownFg) {
          Log("autohide: foreground changed");
          HidePreview();
          return;
        }
        RepositionOrHide();
      }
      // pick up rewrites that the watcher event may have missed
      TryShowPreview();
    }

    private void TryShowPreview() {
      try {
        if (!File.Exists(_ghostPath)) { if (Visible) HidePreview(); return; }
        var stamp = File.GetLastWriteTimeUtc(_ghostPath);
        if (stamp <= _lastFileSeen) return;
        var line = File.ReadAllText(_ghostPath, Encoding.UTF8).Trim();
        if (line.Length == 0) { HidePreview(); return; }
        _lastFileSeen = stamp;
        _text = line;
        _label.Text = line;
        _lastShown = DateTime.UtcNow;
        _shownFg = Native.GetForegroundWindow();
        Log("candidate: " + line);
        RepositionOrHide(true);
      } catch { }
    }

    private void RepositionOrHide(bool force = false) {
      AnchorInfo a;
      string src;
      if (!ResolveAnchor(out a, out src)) {
        if (!Visible) return;
        LogThrottled("hide: no anchor");
        HidePreview();
        return;
      }
      int x, y;
      if (!ComputePlacement(a, out x, out y)) {
        LogThrottled("hide: anchor offscreen " + a);
        HidePreview();
        return;
      }
      PlaceNoActivate(x, y, true);
      if (force) LogThrottled("place src=" + src + " anchor=(" + a.X + "," + a.Top + "," + a.Bottom + ") box=" + x + "," + y + " size=" + Width + "x" + Height);
    }

    // [OVL-ANCHOR-1] UIA caret of the focused text control (same semantic as TSF text extent)
    private bool TryUiaAnchor(out AnchorInfo a) {
      a = default(AnchorInfo);
      try {
        AutomationElement el;
        try { el = AutomationElement.FocusedElement; } catch { return false; }
        while (el != null) {
          object v;
          try { v = el.GetCurrentPropertyValue(AutomationElement.IsTextPatternAvailableProperty, true); }
          catch { v = false; }
          if (v is bool && (bool)v) break;
          if (el == AutomationElement.RootElement) { el = null; break; }
          try { el = TreeWalker.ControlViewWalker.GetParent(el); } catch { el = null; break; }
        }
        if (el == null) return false;
        TextPattern tp;
        try { tp = (TextPattern)el.GetCurrentPattern(TextPattern.Pattern); } catch { return false; }
        TextPatternRange caret = null;
        try {
          TextPatternRange[] sels = tp.GetSelection();
          if (sels != null && sels.Length > 0) caret = sels[0];
        } catch { }
        System.Windows.Rect[] r = null;
        if (caret != null) {
          try { r = caret.GetBoundingRectangles(); } catch { }
          if (r == null || r.Length == 0) {
            try {
              var probe = caret.Clone();
              if (probe.MoveEndpointByUnit(TextPatternRangeEndpoint.End, TextUnit.Character, 1) > 0)
                r = probe.GetBoundingRectangles();
            } catch { }
          }
        }
        if (r == null || r.Length == 0) return false;
        double x = r[0].X, y = r[0].Y, w = r[0].Width, h = r[0].Height;
        if (double.IsNaN(x) || double.IsNaN(y)) return false;
        int top = (int)Math.Round(y);
        int bottom = (h > 0.5) ? (int)Math.Round(y + h) : top + 18;
        a = new AnchorInfo((int)Math.Round(x), top, bottom);
        return true;
      } catch {
        return false;
      }
    }

    // [OVL-ANCHOR-2] Weasel candidate panel of the installed input method
    private bool TryWeaselPanelAnchor(out AnchorInfo a) {
      a = default(AnchorInfo);
      try {
        uint serverPid = 0;
        Process[] procs = Process.GetProcessesByName("WeaselServer");
        if (procs.Length == 0) return false;
        serverPid = (uint)procs[0].Id;
        IntPtr best = IntPtr.Zero;
        long bestArea = -1;
        Native.RECT br = new Native.RECT();
        Native.EnumWindows(delegate(IntPtr hWnd, IntPtr lParam) {
          uint pid;
          Native.GetWindowThreadProcessId(hWnd, out pid);
          if (pid != serverPid || !Native.IsWindowVisible(hWnd)) return true;
          int ex = Native.GetWindowLong(hWnd, Native.GWL_EXSTYLE);
          if ((ex & Native.WS_EX_TOPMOST) == 0 || (ex & Native.WS_EX_TOOLWINDOW) == 0) return true;
          Native.RECT rc;
          if (!Native.GetWindowRect(hWnd, out rc)) return true;
          long area = (long)(rc.Right - rc.Left) * (rc.Bottom - rc.Top);
          if (area <= 0) return true;
          if (area > bestArea) { bestArea = area; best = hWnd; br = rc; }
          return true;
        }, IntPtr.Zero);
        if (best == IntPtr.Zero) return false;
        a = new AnchorInfo(br.Left, br.Top, br.Bottom);
        return true;
      } catch {
        return false;
      }
    }

    // [OVL-ANCHOR-3] Win32 caret (classic edit controls) with dual-space disambiguation
    private bool TryWin32Caret(out AnchorInfo a) {
      a = default(AnchorInfo);
      try {
        IntPtr hwnd = Native.GetForegroundWindow();
        if (hwnd == IntPtr.Zero) return false;
        uint pid;
        uint tid = Native.GetWindowThreadProcessId(hwnd, out pid);
        var info = new Native.GUITHREADINFO();
        info.cbSize = Marshal.SizeOf(info);
        if (!Native.GetGUIThreadInfo(tid, ref info)) return false;
        if (info.hwndCaret == IntPtr.Zero && info.rcCaret.Left == 0 && info.rcCaret.Top == 0) return false;
        Native.RECT wr = new Native.RECT();
        bool hasWr = info.hwndCaret != IntPtr.Zero && Native.GetWindowRect(info.hwndCaret, out wr);
        int nx = info.rcCaret.Left, ny = info.rcCaret.Top;
        var clientPt = new Native.POINT { X = nx, Y = ny };
        bool convOk = false;
        if (info.hwndCaret != IntPtr.Zero)
          convOk = Native.ClientToScreen(info.hwndCaret, ref clientPt);
        int cx = convOk ? clientPt.X : nx;
        int cy = convOk ? clientPt.Y : ny;
        bool naiveInside = hasWr && nx >= wr.Left && nx <= wr.Right && ny >= wr.Top && ny <= wr.Bottom;
        bool convInside = hasWr && cx >= wr.Left && cx <= wr.Right && cy >= wr.Top && cy <= wr.Bottom;
        int x, y;
        if (convOk && naiveInside && !convInside) {
          x = nx; y = ny;                       // rcCaret was already screen space
        } else if (convOk && convInside) {
          x = cx; y = cy;                        // rcCaret was client space
        } else if (convOk) {
          x = cx; y = cy;
        } else if (!naiveInside) {
          return false;
        } else {
          x = nx; y = ny;
        }
        int bottom = (info.rcCaret.Bottom > info.rcCaret.Top)
                       ? y + (info.rcCaret.Bottom - info.rcCaret.Top)
                       : y + 18;
        a = new AnchorInfo(x, y, bottom);
        return true;
      } catch {
        return false;
      }
    }

    private bool ResolveAnchor(out AnchorInfo a, out string src) {
      if (TryUiaAnchor(out a)) { src = "uia"; return true; }
      if (TryWeaselPanelAnchor(out a)) { src = "weasel-panel"; return true; }
      if (TryWin32Caret(out a)) { src = "win32-caret"; return true; }
      // last resort: mouse cursor
      Native.POINT p;
      if (Native.GetCursorPos(out p) && (p.X != 0 || p.Y != 0)) {
        a = new AnchorInfo(p.X, p.Y, p.Y);
        src = "cursor";
        return true;
      }
      a = default(AnchorInfo);
      src = "";
      return false;
    }

    // Weasel-style: below the caret line, flip above when close to screen bottom
    private bool ComputePlacement(AnchorInfo a, out int x, out int y) {
      x = 0; y = 0;
      Screen sc = null;
      foreach (Screen s in Screen.AllScreens) {
        if (s.Bounds.Contains(a.X, a.Bottom) || s.Bounds.Contains(a.X, a.Top)) { sc = s; break; }
      }
      if (sc == null) return false;
      Rectangle wa = sc.WorkingArea;
      int w = Math.Max(Width, 20);
      int h = Math.Max(Height, 24);
      x = a.X;
      y = a.Bottom + 6;
      if (x + w > wa.Right) x = wa.Right - w - 4;
      if (x < wa.Left) x = wa.Left + 4;
      if (y + h > wa.Bottom)
        y = a.Top - h - 6;          // flip above the caret line like the IME candidate window
      if (y < wa.Top) y = wa.Top + 4;
      if (x + w > wa.Right) x = wa.Right - w - 4;
      if (x < wa.Left) x = wa.Left + 4;
      return true;
    }

    private void PlaceNoActivate(int x, int y, bool showIfHidden) {
      uint flags = Native.SWP_NOSIZE | Native.SWP_NOACTIVATE;
      if (showIfHidden || !Visible) flags |= Native.SWP_SHOWWINDOW;
      Native.SetWindowPos(Handle, Native.HWND_TOPMOST, x, y, 0, 0, flags);
      if (!Visible) {
        // WinForms bookkeeping so Visible reflects reality
        ShowWindowNoActivate();
        Native.SetWindowPos(Handle, Native.HWND_TOPMOST, x, y, 0, 0,
                            Native.SWP_NOSIZE | Native.SWP_NOACTIVATE);
      }
    }

    private void ShowWindowNoActivate() {
      try {
        if (Native.ShowWindow(Handle, Native.SW_SHOWNOACTIVATE))
          _shownFg = Native.GetForegroundWindow();
      } catch { }
    }

    private void HidePreview() {
      if (!Visible && _text.Length == 0) return;
      _text = "";
      _label.Text = "";
      if (Visible) Hide();
      _shownFg = IntPtr.Zero;
    }

    private void Log(string message) {
      try {
        Directory.CreateDirectory(_ghostDir);
        File.AppendAllText(_logPath, DateTime.Now.ToString("HH:mm:ss.fff") + " " + message + Environment.NewLine, Encoding.UTF8);
      } catch { }
    }

    private void LogThrottled(string message) {
      var now = DateTime.UtcNow;
      if ((now - _lastLog).TotalMilliseconds < 400) return;
      _lastLog = now;
      Log(message);
    }

    // [OVL-COMMIT] Tab: send the whole prediction to the app
    private void Commit() {
      Log("commit text=[" + _text + "]");
      var text = _text;
      HidePreview();
      try { if (File.Exists(_ghostPath)) File.Delete(_ghostPath); } catch { }
      SendUnicodeText(text);
    }

    private static void SendUnicodeText(string text) {
      if (string.IsNullOrEmpty(text)) return;
      var inputs = new Native.INPUT[text.Length * 2];
      for (int i = 0; i < text.Length; i++) {
        inputs[i * 2].type = Native.INPUT_KEYBOARD;
        inputs[i * 2].ki.wScan = text[i];
        inputs[i * 2].ki.dwFlags = Native.KEYEVENTF_UNICODE;
        inputs[i * 2 + 1].type = Native.INPUT_KEYBOARD;
        inputs[i * 2 + 1].ki.wScan = text[i];
        inputs[i * 2 + 1].ki.dwFlags = Native.KEYEVENTF_UNICODE | Native.KEYEVENTF_KEYUP;
      }
      Native.SendInput((uint)inputs.Length, inputs, Marshal.SizeOf(typeof(Native.INPUT)));
    }

    private IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam) {
      if (nCode >= 0 && wParam.ToInt32() == Native.WM_KEYDOWN) {
        int vk = Marshal.ReadInt32(lParam);
        if (vk == Native.VK_TAB) {
          Log("tab visible=" + Visible + " len=" + _text.Length + " fg=" + (Native.GetForegroundWindow() == _shownFg));
          if (Visible && _text.Length > 0) {
            Commit();
            return (IntPtr)1;      // swallow Tab
          }
        } else {
          // any other key dismisses the current (stale) ghost
          if (Visible) HidePreview();
        }
      }
      return Native.CallNextHookEx(_hook, nCode, wParam, lParam);
    }

    protected override void OnFormClosed(FormClosedEventArgs e) {
      if (_hook != IntPtr.Zero) { Native.UnhookWindowsHookEx(_hook); _hook = IntPtr.Zero; }
      if (_watcher != null) _watcher.Dispose();
      _timer.Dispose();
      base.OnFormClosed(e);
    }

    internal struct AnchorInfo {
      public int X, Top, Bottom;
      public AnchorInfo(int x, int top, int bottom) { X = x; Top = top; Bottom = bottom; }
      public override string ToString() { return X + "," + Top + "," + Bottom; }
    }
  }

  internal static class Program {
    [STAThread]
    private static void Main() {
      Application.EnableVisualStyles();
      Application.SetCompatibleTextRenderingDefault(false);
      Application.Run(new OverlayForm());
    }
  }
}
