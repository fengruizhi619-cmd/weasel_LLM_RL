# 版本归档约定

**规则**
- 每个可复现/可回滚的版本，统一打包成 versions/<版本名>.zip 提交到 git。
- 仓库内不再保留一坨坨实验快照目录；系统上只运行当前实验版本一个。
- 回滚：解压对应 versions/<版本名>.zip 到干净工作树，重新构建即可。

**当前 version 清单**
| zip | 含义 | 基座 |
|-----|------|------|
| cli_emojiless_exp_v0.3.zip | v0.3 外挂基线：原生输入法本体 + 外部上下文/候选树/RL 链路 | v0.3 |
| cli_emojiless_exp_v0.3_textshow.zip | TSF 内嵌预览实验（已废弃，记事本会把预览顶成真文本） | textshow |
| cli_emojiless_exp_v0.3_textshow_tsf_experiments.zip | 文本显示实验过程中 13 个 weaselx64.dll 快照 | textshow |
| WeaselOverlayV0_abandoned.zip | 外部窗口预览工具（已废弃，改用输入法候选框注入） | overlay |
| cli_emojiless_RL_v1.zip | 在线 RL 引擎托管进 WeaselServer | v1 |
| cli_emojiless_RL_v1.1.zip | 离线记录模式、语言栏模式切换、兄弟节点批量前向 | v1.1 |
| cli_emojiless_RL_v1.2.zip | 数据面板、无头离线训练与进度、入口去 cmd 窗口、脚本编码修复 | v1.2 |
| cli_emojiless_RL_v1.2.1.zip | 安装器从 Release 拉模型（-DownloadModels / -ModelsOnly / -Mirror） | v1.2.1 |
| cli_emojiless_RL_v1.3.zip | 拼音前缀匹配、top-k 免建树训练、checkpoint 同步防覆盖、Tab 防僵尸预测 | v1.3 |
| cli_emojiless_RL_v1.4.zip | 在线离线统一：逐 token 排名奖励、每次提交都训练、未命中走负样本 | v1.4 |
| cli_emojiless_RL_v2.0.zip | **第一个可正式训练的版本**：纯交叉熵 + 普通 SGD + lr 1e-5 + 打字/小说 25% 混料；新增 train_mix.py 与三指标验收；清理早期原型与死代码 | v2.0 |
| cli_emojiless_RL_v2.0.1.zip | 解码器库与面板切换区；修面板裁切 bug；线上切到 mix_base | v2.0.1 |
| cli_emojiless_RL_v2.0.2.zip | 看门狗改无头启动（修每 5 分钟闪窗）；注册脚本修 Duration 越界 + 加硬断言与 -DryRun；codex→DSH 残留硬路径 | v2.0.2 |
| cli_emojiless_RL_v2.0.3.zip | 修数据面板打不开：启动器不再依赖 ghost_home.txt 的编码（安装期把仓库路径写进 .cmd）；install.ps1 加同哈希跳过与编码回读校验；新增现场修复工具 fix-ghost-launcher.ps1 | v2.0.3 |

**当前工作树**
- 基座：cli_emojiless_RL_v2.0.3（HEAD）
- 活动实验：tools\LlamaTreeExp + tools\WeaselExpContextV0（外部钩子/候选树/训练）
- 定型配置：纯交叉熵 / 普通 SGD / lr 1e-5 / 梯度裁剪关闭 / 打字:小说 = 25:75
- 工作区位置：E:\DSH_data\研究\weasel-baseline（原 E:\codex_data\研究，已迁移）
- 无头看门狗：计划任务动作必须是 `wscript.exe ... watchdog.vbs`，不能是 powershell.exe（会闪窗）。
  改动后需在管理员会话跑一次 output\register-task.ps1 才生效。
- 启动器路径：ghost_*.cmd 的仓库路径由 install.ps1 在安装期以 ASCII 字面量写入（@@GHOST_HOME@@ 占位）。
  **不要**再让它们回去读 ghost_home.txt —— cmd 的 `set /p` 按 ANSI 读，文件一旦被写成 UTF-8 就静默失效。
  现场修复用 output\fix-ghost-launcher.ps1（带 -DryRun / -Launch）。
- 下一步：验证超大数据量下的泛化（当前只到 1 万字、17001 步；同域 +3 点，换书换文体无数据）
